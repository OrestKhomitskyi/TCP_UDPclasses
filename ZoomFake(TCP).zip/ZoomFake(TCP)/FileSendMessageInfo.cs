﻿namespace ZoomFake_TCP_
{
    public class FileSendMessageInfo
    {
    }
}
